export interface Lookup {

     CATEGORY: string;
     NAME: string;
     LTYPE: string;
     ID: string;
     PARENT_ID: number;
}
